export class Product {
  constructor(public id: string,
              public name: string,
              public imgUrl: string,
              public description: string) {
  }
}
