import {Component} from '@angular/core';

@Component({
  selector: 'app-hero-remove',
  templateUrl: './hero-remove.component.html',
})

export class HeroRemoveComponent {
  constructor() {
  }
}
